const secretKey = "ULTRA SECRET KEY :O"

module.exports = { secretKey }